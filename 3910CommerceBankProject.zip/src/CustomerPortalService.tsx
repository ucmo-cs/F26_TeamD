// Service file for CustomerPortal.tsx


export type Loan = {
    id: number;
    amount: number;
    interest: number;
    amountRemaining: number;
    dateCreated: string;
    loanDurationYears: number;
};

// export and return the loans to front-end
export function getLoans(): Loan[] {
    return [
        {
            id: 1,
            amount: 15000,
            interest: 12,
            amountRemaining: 12000,
            dateCreated: "2026-08-22",
            loanDurationYears: 3,
        },
        {
            id: 2,
            amount: 20000,
            interest: 4,
            amountRemaining: 15000,
            dateCreated: "2023-05-13",
            loanDurationYears: 5,
        },
    ];
}

// returns minimum payment based off of amountReamining and interest
// uses Standard Amortization Formula
export function calculateMinimumPayment(loan: Loan): number {
    //get percentile of monthly interest and amount of months to pay
    const monthlyRate = loan.interest / 100 / 12;
    const numberOfPayments = loan.loanDurationYears * 12

    if (numberOfPayments <= 0) return 0;

    if (monthlyRate === 0) {
        return loan.amountRemaining / numberOfPayments;
    }
    const factor = (1 + monthlyRate) ** numberOfPayments;

    //return value at 2 decimal point value
    return Math.round((loan.amountRemaining * monthlyRate * factor) / (factor - 1) * 100) / 100;
}

// Returns informational list of selected Loan
export function LoanInfo({loan, onMakePayment,}: { loan: Loan; onMakePayment?: () => void; }) {
    return (

        // returns a box to be displayed
        <div className="loanBox">
            <h1>Loan {loan.id}</h1>
            <p>Loan Amount: ${loan.amount.toLocaleString()}</p>
            <p>Interest: {loan.interest}%</p>
            <p>Amount Remaining: ${loan.amountRemaining.toLocaleString()}</p>
            <p>Loan Duration: {loan.loanDurationYears}</p>
            <p>Date loan was created: {loan.dateCreated}</p>

            {/*Payment button for selected loan*/}
            {onMakePayment && (
                <button className="payment" onClick={onMakePayment}>
                    Make a Payment
                </button>
            )}
        </div>
    );
}

// keep payment process out of front-end
export function processPayment(loan: Loan, amount: number): Loan {
    const minimum = calculateMinimumPayment(loan);

    if (
        !Number.isFinite(amount) ||
        amount < minimum ||
        amount > loan.amountRemaining
    ) {
        throw new Error("Payment must be between the minimum and remaining balance");
    }

    return {
        ...loan, amountRemaining: loan.amountRemaining - amount,
    };
}
